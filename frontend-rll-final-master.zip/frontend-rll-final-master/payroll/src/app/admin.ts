export class Admin {
    empId: number;
    fName: string;
    lName: string ;
	dob: string ;	
	gender: string ; 
	street: string ;
	location: string ; 
	city: string ; 
	state: string ; 
	pincode: number ; 
	mobNo: string ; 
	emailId: string ; 
	password: string ;
	designation: string ;
}
