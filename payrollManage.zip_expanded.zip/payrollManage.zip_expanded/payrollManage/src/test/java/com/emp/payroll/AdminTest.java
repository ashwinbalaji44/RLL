package com.emp.payroll;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;

import com.emp.payroll.model.Admin;
import com.emp.payroll.model.Employee;
import com.emp.payroll.repository.AdminRegistrationRepository;
import com.emp.payroll.repository.AdminRepository;
import com.emp.payroll.repository.RegistrationRepository;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class AdminTest {

	@Autowired
	AdminRegistrationRepository adrRepo;
	@Test
	@Order(1)
	public void testcreate() {
		Admin a = new Admin();
		a.setId(10000);
		a.setEmailId("abc@gmail.com");
		a.setPassword("abc123");
		a.setUserName("abc");
		adrRepo.save(a);
		a.setId(10001);
		a.setEmailId("def@gmail.com");
		a.setPassword("def123");
		a.setUserName("def");
		adrRepo.save(a);
		assertNotNull(adrRepo.findById(10000).get());

	}
	
	@Test
	@Order(2)
	public void testSingleProduct() {
		Admin admin=adrRepo.findById(10000).get();
		assertEquals("abc123",admin.getPassword());
	}
	
	@Test
	@Order(3)
	public void testUpdate() {
		Admin a=adrRepo.findById(10000).get();
		a.setPassword("admin");
		adrRepo.save(a);
		assertNotEquals("abc123",adrRepo.findById(10000).get().getPassword());
	}
	
	@Test
	@Order(4)
	public void testDelete() {
		adrRepo.deleteById(10001);
		assertThat(adrRepo.existsById(10001)).isFalse();
	}
	
}